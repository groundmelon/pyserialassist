#!/usr/bin/env python
import MainFrame

app = MainFrame.App(redirect=False)
app.MainLoop()